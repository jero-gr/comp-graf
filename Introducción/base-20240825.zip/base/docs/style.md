## Coding Style and Naming conventions

Convención de nombres utilizado para archivos e identificadores en los códigos fuentes propios (dentro de `src` y `utils`):

* `variable_or_attribute`
* `ClassOrStruct`
* `functionOrMethod`
* `HeaderFileName.hpp`
* `SourceFileName.cpp`

**To-do**: completar

